<div align="center">

<h1 style="font-family:'Orbitron', monospace; color:#00ffea; animation:scroll 8s linear infinite; white-space:nowrap;">
😍𝐋𝐔𝐌𝐈𝐍𝐀 𝐌𝐃😍
</h1>

<img src="https://files.catbox.moe/z7047y.jpg" width="160" style="border-radius:20px; box-shadow:0 0 40px #00ffea;" />

<p style="font-family:'Share Tech Mono', monospace; color:#9afff6;">

<h1 align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code:wght@700&size=32&duration=6000&color=00FF00&background=000000&center=true&vCenter=true&width=900&lines=LUMINA+MD+THE+BEST+BOT+WHATSAPP+100%2B+FEATURES" alt="Typing Animation">
</h1>

## <a name="panel-setup"></a>💻Panel Deployment Guide

Use this guide if you are deploying on
**Optilink,Pterodactyl,Katabump, Render, or GitHub**.

## 🔗 Connect With Us

### Project Owner: Dev Weed
<a href='https://wa.me/+50939032060?text=*_Hello+Dev Weed👋_*' target="_blank">
  <img alt='WhatsApp' src='https://img.shields.io/badge/Contact_Owner-0033CC?style=for-the-badge&logo=whatsapp&logoColor=white'/>
</a>

### Join Our Community
<a href="https://chat.whatsapp.com/KfYnvgj0JTqErxKc0RTNNu">
  <img src="https://img.shields.io/badge/Join_Group-00FF00?style=for-the-badge&logo=whatsapp" alt="WhatsApp Group"/>
</a>
<a href="https://whatsapp.com/channel/0029Vb2J9C91dAw7vxA75y2V">
  <img src="https://img.shields.io/badge/Join_Channel-FF69B4?style=for-the-badge&logo=whatsapp" alt="WhatsApp Channel"/>
</a>

</div>

<div align="center">
  <a href="https://t.me/WeedTechgroup">
    <img src="https://img.shields.io/badge/-TELEGRAM%20CHANNEL-0088cc?style=for-the-badge&logo=telegram&logoColor=white" height="35" alt="Telegram"/>
  </a>
  <a href=
    
  <p align="center">
  <a href="https://www.youtube.com/@WeedTech-e1m">
    <img title="DEPLOY LUMINA-MD" src="https://img.shields.io/badge/🚀_TUTORIAL_VEDEO_HERE-000000?style=for-the-badge&logo=heroku&logoColor=white&color=FF00FF" width="260" height="50"/>
  </a>
</p





















### 📜 License

MIT © 𝐖𝐞𝐞𝐝 𝐓𝐞𝐜𝐡 

module.exports = {
  Number: "18494869204" // remplacez par votre numéro WhatsApp sans mettre le signe +
};
